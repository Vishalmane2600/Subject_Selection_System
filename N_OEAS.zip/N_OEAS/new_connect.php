<?php
Class dbObj
{
var $dbHost     = "localhost";
var $dbUsername = "root";
var $dbPassword = "";
var $dbName     = "open_elective_allotment_system";
var $conn;
function getconnstring()
{
    $con=mysqli_connect($this->dbhost,$this->dbusername,$this->dbPassword,$this->dbName) or die("Connection Failed : ")

    if(mysqli_connect_errno())
    {
        print("Connection failed : %s\n",mysqli_connect_error());
        exit();
    }
    else{
        $this->conn=$con;
    }
    return $this->conn;
    }
}
