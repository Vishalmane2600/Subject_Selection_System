<?php
require ('mpdf/autoload.php');
include "database connectivity.php";
$sql="SELECT NAME,URN,BRANCH,COURSENAME FROM ALLOTMENT";
$res=mysqli_query($db,$sql);
if(mysqli_num_rows($res)>0)
{
    $html='<style></stlye><table class="table">';
        $html.='<tr><td>NAME</td><td>URN</td><td>BRANCH</td><td>COURSENAME</td>';
        while($row=mysqli_fetch_assoc($res))
{
    
    $html.='<tr><td>'.$row['NAME'].'</td><td>'.$row['URN'].'</td><td>'.$row['BRANCH'].'</td><td>'.$row['COURSENAME'].'</td></tr>';
}
$html.='</table>';
}
else{
    $html="Data Not Found!!";
}
$mpdf=new \Mpdf\Mpdf();
$mpdf->WriteHTML($html);
$file=allotment().'.pdf';
$mpdf->output($file,'I');
?>