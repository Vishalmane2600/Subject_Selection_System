<?php 
include "database connectivity.php"
?>

<html>  
<head>
	<title>Branch</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>  
    <body>
    <h2 style="font-family:Times New Roman;">Branch Wise Download List</h2>
    <form>
    <input type="button" value="Print" onclick="window.print()" />
</form>
    <!-- Data list table --> 
    <table class="table table-striped table-bordered">
        
            <tr>        
                                
                               <th>NAME</th> 
                               <th>URN</th>
                               <th>BRANCH</th>  
                               <th>COURSENAME</th>  

            </tr>
        </thead>
        <tbody>
        <?php
        // Get member rows
        $sql = "SELECT  distinct u.URN,u.NAME,u1.BRANCH,u.COURSENAME
        FROM allotment u,allotment u1
        WHERE u.BRANCH=u1.BRANCH
        ORDER BY BRANCH";

        $result = $db->query($sql);

        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
        ?>
            <tr>
    <td><?php echo $row["NAME"]; ?></td>
    <td><?php echo $row["URN"]; ?></td>  
    <td><?php echo $row["BRANCH"]; ?></td>  
    <td><?php echo $row["COURSENAME"]; ?></td>

            </tr>
        <?php } }else{ ?>
            <tr><td colspan="5">No member(s) found...</td></tr>
        <?php } ?>
        </tbody>
    </table>
</div>
        </body>
</html>










