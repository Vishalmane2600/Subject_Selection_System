<!DOCTYPE html>
<html>
<body>
 
<?php
 
 echo "<script type='text/javascript'> alert('Log out Successfully..'); 
 window.location='index.html';</script>";
 
    session_start();
    session_destroy();
 
?>
 
</body>
</html>